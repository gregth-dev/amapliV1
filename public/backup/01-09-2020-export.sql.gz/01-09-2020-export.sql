-- Created at 1.9.2020 14:57 using David Grudl MySQL Dump Utility
-- Host: localhost:8000
-- MySQL Server: 8.0.18
-- Database: escalamap

SET NAMES utf8;
SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET FOREIGN_KEY_CHECKS=0;
SET UNIQUE_CHECKS=0;
SET AUTOCOMMIT=0;
-- --------------------------------------------------------

DROP TABLE IF EXISTS `contract`;

CREATE TABLE `contract` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producer_id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `frequency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `limit_date` datetime NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `informations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `multidistribution` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_E98F285989B658FE` (`producer_id`),
  CONSTRAINT `FK_E98F285989B658FE` FOREIGN KEY (`producer_id`) REFERENCES `producer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `contract` DISABLE KEYS;

INSERT INTO `contract` (`id`, `producer_id`, `name`, `frequency`, `limit_date`, `start_date`, `end_date`, `status`, `informations`, `multidistribution`, `created_at`) VALUES
(11,	3,	'Contrat des fruits',	'+7days',	'2020-08-31 14:14:15',	'2020-09-01 14:14:15',	'2020-09-29 14:14:15',	'actif',	NULL,	0,	'2020-08-29 12:52:11'),
(13,	8,	'Contrat des légumes',	'null',	'2020-01-06 12:59:02',	'2020-01-07 12:59:02',	'2020-12-29 12:59:02',	'actif',	NULL,	0,	'2020-08-30 23:35:15');
ALTER TABLE `contract` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `contract_member`;

CREATE TABLE `contract_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_id` int(11) NOT NULL,
  `subscriber_id` int(11) NOT NULL,
  `total_amount` double NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4CA41F352576E0FD` (`contract_id`),
  KEY `IDX_4CA41F357808B1AD` (`subscriber_id`),
  CONSTRAINT `FK_4CA41F352576E0FD` FOREIGN KEY (`contract_id`) REFERENCES `contract` (`id`),
  CONSTRAINT `FK_4CA41F357808B1AD` FOREIGN KEY (`subscriber_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `contract_member` DISABLE KEYS;

INSERT INTO `contract_member` (`id`, `contract_id`, `subscriber_id`, `total_amount`, `status`, `created_at`) VALUES
(9,	11,	5,	150,	'actif',	'2020-08-29 12:52:40'),
(10,	11,	55,	120,	'actif',	'2020-08-29 22:18:22'),
(15,	13,	54,	1200,	'actif',	'2020-08-31 02:53:52');
ALTER TABLE `contract_member` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `delivery`;

CREATE TABLE `delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_3781EC102576E0FD` (`contract_id`),
  CONSTRAINT `FK_3781EC102576E0FD` FOREIGN KEY (`contract_id`) REFERENCES `contract` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=282 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `delivery` DISABLE KEYS;

INSERT INTO `delivery` (`id`, `contract_id`, `date`, `status`) VALUES
(94,	11,	'2020-09-01 14:14:15',	NULL),
(95,	11,	'2020-09-08 14:14:15',	'Annulée'),
(96,	11,	'2020-09-15 14:14:15',	NULL),
(97,	11,	'2020-09-22 14:14:15',	'Reportée'),
(98,	11,	'2020-09-29 14:14:15',	NULL),
(104,	11,	'2020-08-31 14:14:15',	NULL),
(216,	13,	'2020-01-07 12:59:02',	NULL),
(217,	13,	'2020-01-14 12:59:02',	NULL),
(218,	13,	'2020-01-21 12:59:02',	NULL),
(219,	13,	'2020-01-28 12:59:02',	NULL),
(220,	13,	'2020-02-04 12:59:02',	NULL),
(221,	13,	'2020-02-11 12:59:02',	NULL),
(222,	13,	'2020-02-18 12:59:02',	NULL),
(223,	13,	'2020-02-25 12:59:02',	NULL),
(224,	13,	'2020-03-03 12:59:02',	NULL),
(239,	13,	'2020-06-16 12:59:02',	NULL),
(240,	13,	'2020-06-23 12:59:02',	NULL),
(241,	13,	'2020-06-30 12:59:02',	NULL),
(242,	13,	'2020-07-07 12:59:02',	NULL),
(243,	13,	'2020-07-14 12:59:02',	NULL),
(244,	13,	'2020-07-21 12:59:02',	NULL),
(245,	13,	'2020-07-28 12:59:02',	NULL),
(246,	13,	'2020-08-04 12:59:02',	NULL),
(247,	13,	'2020-08-11 12:59:02',	NULL),
(248,	13,	'2020-08-18 12:59:02',	NULL),
(249,	13,	'2020-08-25 12:59:02',	NULL),
(250,	13,	'2020-09-01 12:59:02',	NULL),
(251,	13,	'2020-09-08 12:59:02',	NULL),
(252,	13,	'2020-09-15 12:59:02',	NULL),
(253,	13,	'2020-09-22 12:59:02',	NULL),
(254,	13,	'2020-09-29 12:59:02',	NULL),
(255,	13,	'2020-10-06 12:59:02',	NULL),
(256,	13,	'2020-10-13 12:59:02',	NULL),
(257,	13,	'2020-10-20 12:59:02',	NULL),
(258,	13,	'2020-10-27 12:59:02',	NULL),
(259,	13,	'2020-11-03 12:59:02',	NULL),
(260,	13,	'2020-11-10 12:59:02',	NULL),
(261,	13,	'2020-11-17 12:59:02',	NULL),
(262,	13,	'2020-11-24 12:59:02',	NULL),
(263,	13,	'2020-12-01 12:59:02',	NULL),
(264,	13,	'2020-12-08 12:59:02',	NULL),
(265,	13,	'2020-12-15 12:59:02',	NULL),
(266,	13,	'2020-12-22 12:59:02',	NULL),
(267,	13,	'2020-12-29 12:59:02',	NULL),
(276,	13,	'2020-12-24 12:59:02',	'Annulée'),
(277,	13,	'2020-10-22 12:59:02',	'A Confirmer');
ALTER TABLE `delivery` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `doctrine_migration_versions`;

CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `doctrine_migration_versions` DISABLE KEYS;

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20200827084720',	'2020-08-27 08:47:37',	66),
('DoctrineMigrations\\Version20200827123549',	'2020-08-27 12:35:56',	914),
('DoctrineMigrations\\Version20200827135002',	'2020-08-27 13:50:17',	491),
('DoctrineMigrations\\Version20200827160303',	'2020-08-27 16:03:13',	312),
('DoctrineMigrations\\Version20200827185628',	'2020-08-27 18:57:33',	108),
('DoctrineMigrations\\Version20200827201606',	'2020-08-27 20:16:21',	942),
('DoctrineMigrations\\Version20200827203141',	'2020-08-27 20:31:47',	89),
('DoctrineMigrations\\Version20200828150633',	'2020-08-28 15:07:00',	484),
('DoctrineMigrations\\Version20200828153044',	'2020-08-28 15:31:03',	283),
('DoctrineMigrations\\Version20200828154637',	'2020-08-28 15:46:42',	34),
('DoctrineMigrations\\Version20200828201235',	'2020-08-28 20:12:46',	790),
('DoctrineMigrations\\Version20200828203131',	'2020-08-28 20:31:39',	111),
('DoctrineMigrations\\Version20200828234022',	'2020-08-28 23:40:30',	53),
('DoctrineMigrations\\Version20200829004048',	'2020-08-29 00:40:53',	51),
('DoctrineMigrations\\Version20200829075821',	'2020-08-29 07:58:27',	969);
ALTER TABLE `doctrine_migration_versions` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `document`;

CREATE TABLE `document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `update_date` datetime DEFAULT NULL,
  `information` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `document` DISABLE KEYS;

INSERT INTO `document` (`id`, `name`, `type`, `created_at`, `update_date`, `information`) VALUES
(1,	'Document test',	'pdf',	'2020-08-28 17:47:49',	NULL,	'planning'),
(4,	'doc test',	'pdf',	'2020-08-30 01:10:08',	NULL,	NULL);
ALTER TABLE `document` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `donation`;

CREATE TABLE `donation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `donor_id` int(11) DEFAULT NULL,
  `amount` double NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_31E581A03DD7B7A7` (`donor_id`),
  CONSTRAINT `FK_31E581A03DD7B7A7` FOREIGN KEY (`donor_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `donation` DISABLE KEYS;

INSERT INTO `donation` (`id`, `donor_id`, `amount`, `created_at`) VALUES
(1,	5,	50,	'2020-08-29 02:07:44');
ALTER TABLE `donation` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `donation_payment`;

CREATE TABLE `donation_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `donation_id` int(11) NOT NULL,
  `check_number` int(11) NOT NULL,
  `amount` double NOT NULL,
  `deposit_date` datetime NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `check_order` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_478478BD4DC1279C` (`donation_id`),
  CONSTRAINT `FK_478478BD4DC1279C` FOREIGN KEY (`donation_id`) REFERENCES `donation` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `donation_payment` DISABLE KEYS;

INSERT INTO `donation_payment` (`id`, `donation_id`, `check_number`, `amount`, `deposit_date`, `status`, `check_order`) VALUES
(1,	1,	5565872,	50,	'2020-08-29 08:51:34',	'non remis',	'escalamap');
ALTER TABLE `donation_payment` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `file`;

CREATE TABLE `file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8C9F3610C33F7837` (`document_id`),
  CONSTRAINT `FK_8C9F3610C33F7837` FOREIGN KEY (`document_id`) REFERENCES `document` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `file` DISABLE KEYS;

INSERT INTO `file` (`id`, `document_id`, `name`) VALUES
(1,	1,	'planning-5f4927265e291.pdf'),
(4,	4,	'feuillepresence-GREGORY-THOREL-AVRIL-2020-5f4ae05095215.pdf');
ALTER TABLE `file` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `order`;

CREATE TABLE `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `contract_member_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_F52993984584665A` (`product_id`),
  KEY `IDX_F529939858008B68` (`contract_member_id`),
  CONSTRAINT `FK_F52993984584665A` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FK_F529939858008B68` FOREIGN KEY (`contract_member_id`) REFERENCES `contract_member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `order` DISABLE KEYS;

INSERT INTO `order` (`id`, `product_id`, `contract_member_id`, `quantity`, `unit_price`) VALUES
(8,	4,	9,	1,	30),
(9,	3,	10,	1,	20),
(13,	9,	15,	1,	30);
ALTER TABLE `order` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `order_delivery`;

CREATE TABLE `order_delivery` (
  `order_id` int(11) NOT NULL,
  `delivery_id` int(11) NOT NULL,
  PRIMARY KEY (`order_id`,`delivery_id`),
  KEY `IDX_D6790EA18D9F6D38` (`order_id`),
  KEY `IDX_D6790EA112136921` (`delivery_id`),
  CONSTRAINT `FK_D6790EA112136921` FOREIGN KEY (`delivery_id`) REFERENCES `delivery` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_D6790EA18D9F6D38` FOREIGN KEY (`order_id`) REFERENCES `order` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `order_delivery` DISABLE KEYS;

INSERT INTO `order_delivery` (`order_id`, `delivery_id`) VALUES
(8,	94),
(8,	95),
(8,	96),
(8,	97),
(8,	98),
(9,	94),
(9,	95),
(9,	96),
(9,	97),
(9,	98),
(9,	104),
(13,	216),
(13,	217),
(13,	218),
(13,	219),
(13,	220),
(13,	221),
(13,	222),
(13,	223),
(13,	224),
(13,	239),
(13,	240),
(13,	241),
(13,	242),
(13,	243),
(13,	244),
(13,	245),
(13,	246),
(13,	247),
(13,	248),
(13,	249),
(13,	250),
(13,	251),
(13,	252),
(13,	253),
(13,	254),
(13,	255),
(13,	256),
(13,	257),
(13,	258),
(13,	259),
(13,	260),
(13,	261),
(13,	262),
(13,	263),
(13,	264),
(13,	265),
(13,	266),
(13,	267),
(13,	276),
(13,	277);
ALTER TABLE `order_delivery` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `organism`;

CREATE TABLE `organism` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `organism` DISABLE KEYS;

INSERT INTO `organism` (`id`, `name`, `amount`) VALUES
(1,	'Association Escalamap',	15),
(2,	'Association Région Amap',	20);
ALTER TABLE `organism` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `payment`;

CREATE TABLE `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contract_member_id` int(11) NOT NULL,
  `producer_id` int(11) NOT NULL,
  `check_number` int(11) NOT NULL,
  `amount` double NOT NULL,
  `deposit_date` datetime NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_6D28840D58008B68` (`contract_member_id`),
  KEY `IDX_6D28840D89B658FE` (`producer_id`),
  CONSTRAINT `FK_6D28840D58008B68` FOREIGN KEY (`contract_member_id`) REFERENCES `contract_member` (`id`),
  CONSTRAINT `FK_6D28840D89B658FE` FOREIGN KEY (`producer_id`) REFERENCES `producer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `payment` DISABLE KEYS;

INSERT INTO `payment` (`id`, `contract_member_id`, `producer_id`, `check_number`, `amount`, `deposit_date`, `status`) VALUES
(2,	9,	3,	125697856,	50,	'2020-09-01 10:56:30',	'remis'),
(3,	9,	3,	56526526,	50,	'2020-10-01 10:56:30',	'remis'),
(4,	9,	3,	52669811,	50,	'2020-10-01 10:56:30',	'remis'),
(5,	10,	3,	125697856,	120,	'2020-08-29 20:18:44',	'remis'),
(6,	15,	8,	2147483647,	1200,	'2020-08-31 00:55:08',	'remis');
ALTER TABLE `payment` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `permanence`;

CREATE TABLE `permanence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `number_places` int(11) NOT NULL,
  `informations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `permanence` DISABLE KEYS;

INSERT INTO `permanence` (`id`, `date`, `number_places`, `informations`, `created_at`) VALUES
(2,	'2020-09-29 15:19:42',	4,	NULL,	'2020-08-28 17:19:42');
ALTER TABLE `permanence` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `permanence_user`;

CREATE TABLE `permanence_user` (
  `permanence_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`permanence_id`,`user_id`),
  KEY `IDX_CCB60EA1A9457964` (`permanence_id`),
  KEY `IDX_CCB60EA1A76ED395` (`user_id`),
  CONSTRAINT `FK_CCB60EA1A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_CCB60EA1A9457964` FOREIGN KEY (`permanence_id`) REFERENCES `permanence` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `permanence_user` DISABLE KEYS;

ALTER TABLE `permanence_user` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `producer`;

CREATE TABLE `producer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `referent_id` int(11) NOT NULL,
  `substitute_id` int(11) DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `check_order` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_976449DCA76ED395` (`user_id`),
  UNIQUE KEY `UNIQ_976449DC5E237E06` (`name`),
  UNIQUE KEY `UNIQ_976449DC6F73A05A` (`check_order`),
  KEY `IDX_976449DC35E47E35` (`referent_id`),
  KEY `IDX_976449DC19ECAD51` (`substitute_id`),
  CONSTRAINT `FK_976449DC19ECAD51` FOREIGN KEY (`substitute_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_976449DC35E47E35` FOREIGN KEY (`referent_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_976449DCA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `producer` DISABLE KEYS;

INSERT INTO `producer` (`id`, `user_id`, `referent_id`, `substitute_id`, `name`, `check_order`) VALUES
(3,	16,	8,	NULL,	'Producteur des fruits',	'producteur des fruits'),
(4,	6,	53,	NULL,	'Producteur du pain',	'producteur du pain'),
(8,	30,	53,	NULL,	'Producteur des légumes',	'producteur des légumes');
ALTER TABLE `producer` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producer_id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D34A04AD89B658FE` (`producer_id`),
  CONSTRAINT `FK_D34A04AD89B658FE` FOREIGN KEY (`producer_id`) REFERENCES `producer` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `product` DISABLE KEYS;

INSERT INTO `product` (`id`, `producer_id`, `name`, `details`, `price`) VALUES
(3,	3,	'Panier de fruits',	'1/2 panier de fruits de saison',	20),
(4,	3,	'Panier de fruits',	'1 panier de fruits de saison',	30),
(9,	8,	'panier de légumes',	'1 panier de légumes 4 personnes',	30);
ALTER TABLE `product` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `product_order`;

CREATE TABLE `product_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscriber_id` int(11) NOT NULL,
  `command_id` int(11) NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_5475E8C47808B1AD` (`subscriber_id`),
  KEY `IDX_5475E8C433E1689A` (`command_id`),
  CONSTRAINT `FK_5475E8C433E1689A` FOREIGN KEY (`command_id`) REFERENCES `order` (`id`),
  CONSTRAINT `FK_5475E8C47808B1AD` FOREIGN KEY (`subscriber_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=376 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `product_order` DISABLE KEYS;

INSERT INTO `product_order` (`id`, `subscriber_id`, `command_id`, `status`, `date`) VALUES
(90,	5,	8,	NULL,	'2020-09-01 14:14:15'),
(91,	5,	8,	'Annulée',	'2020-09-08 14:14:15'),
(92,	5,	8,	NULL,	'2020-09-15 14:14:15'),
(93,	5,	8,	'Reportée',	'2020-09-22 14:14:15'),
(94,	5,	8,	NULL,	'2020-09-29 14:14:15'),
(95,	5,	8,	NULL,	'2020-08-31 14:14:15'),
(96,	55,	9,	NULL,	'2020-09-01 14:14:15'),
(97,	55,	9,	'Annulée',	'2020-09-08 14:14:15'),
(98,	55,	9,	NULL,	'2020-09-15 14:14:15'),
(99,	55,	9,	'Reportée',	'2020-09-22 14:14:15'),
(100,	55,	9,	NULL,	'2020-09-29 14:14:15'),
(101,	55,	9,	NULL,	'2020-08-31 14:14:15'),
(336,	54,	13,	NULL,	'2020-01-07 12:59:02'),
(337,	54,	13,	NULL,	'2020-01-14 12:59:02'),
(338,	54,	13,	NULL,	'2020-01-21 12:59:02'),
(339,	54,	13,	NULL,	'2020-01-28 12:59:02'),
(340,	54,	13,	NULL,	'2020-02-04 12:59:02'),
(341,	54,	13,	NULL,	'2020-02-11 12:59:02'),
(342,	54,	13,	NULL,	'2020-02-18 12:59:02'),
(343,	54,	13,	NULL,	'2020-02-25 12:59:02'),
(344,	54,	13,	NULL,	'2020-03-03 12:59:02'),
(345,	54,	13,	NULL,	'2020-06-16 12:59:02'),
(346,	54,	13,	NULL,	'2020-06-23 12:59:02'),
(347,	54,	13,	NULL,	'2020-06-30 12:59:02'),
(348,	54,	13,	NULL,	'2020-07-07 12:59:02'),
(349,	54,	13,	NULL,	'2020-07-14 12:59:02'),
(350,	54,	13,	NULL,	'2020-07-21 12:59:02'),
(351,	54,	13,	NULL,	'2020-07-28 12:59:02'),
(352,	54,	13,	NULL,	'2020-08-04 12:59:02'),
(353,	54,	13,	NULL,	'2020-08-11 12:59:02'),
(354,	54,	13,	NULL,	'2020-08-18 12:59:02'),
(355,	54,	13,	NULL,	'2020-08-25 12:59:02'),
(356,	54,	13,	NULL,	'2020-09-01 12:59:02'),
(357,	54,	13,	NULL,	'2020-09-08 12:59:02'),
(358,	54,	13,	NULL,	'2020-09-15 12:59:02'),
(359,	54,	13,	NULL,	'2020-09-22 12:59:02'),
(360,	54,	13,	NULL,	'2020-09-29 12:59:02'),
(361,	54,	13,	NULL,	'2020-10-06 12:59:02'),
(362,	54,	13,	NULL,	'2020-10-13 12:59:02'),
(363,	54,	13,	NULL,	'2020-10-20 12:59:02'),
(364,	54,	13,	NULL,	'2020-10-27 12:59:02'),
(365,	54,	13,	NULL,	'2020-11-03 12:59:02'),
(366,	54,	13,	NULL,	'2020-11-10 12:59:02'),
(367,	54,	13,	NULL,	'2020-11-17 12:59:02'),
(368,	54,	13,	NULL,	'2020-11-24 12:59:02'),
(369,	54,	13,	NULL,	'2020-12-01 12:59:02'),
(370,	54,	13,	NULL,	'2020-12-08 12:59:02'),
(371,	54,	13,	NULL,	'2020-12-15 12:59:02'),
(372,	54,	13,	NULL,	'2020-12-22 12:59:02'),
(373,	54,	13,	NULL,	'2020-12-29 12:59:02'),
(374,	54,	13,	'Annulée',	'2020-12-24 12:59:02'),
(375,	54,	13,	'A Confirmer',	'2020-10-22 12:59:02');
ALTER TABLE `product_order` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `subscription`;

CREATE TABLE `subscription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscriber_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `year` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_valid` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_A3C664D37808B1AD` (`subscriber_id`),
  CONSTRAINT `FK_A3C664D37808B1AD` FOREIGN KEY (`subscriber_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `subscription` DISABLE KEYS;

INSERT INTO `subscription` (`id`, `subscriber_id`, `created_at`, `year`, `is_valid`) VALUES
(1,	6,	'2020-08-29 02:37:13',	'2020',	1),
(3,	5,	'2020-08-30 12:03:00',	'2020',	1);
ALTER TABLE `subscription` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `subscription_organism`;

CREATE TABLE `subscription_organism` (
  `subscription_id` int(11) NOT NULL,
  `organism_id` int(11) NOT NULL,
  PRIMARY KEY (`subscription_id`,`organism_id`),
  KEY `IDX_6AFDD5009A1887DC` (`subscription_id`),
  KEY `IDX_6AFDD50064180A36` (`organism_id`),
  CONSTRAINT `FK_6AFDD50064180A36` FOREIGN KEY (`organism_id`) REFERENCES `organism` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_6AFDD5009A1887DC` FOREIGN KEY (`subscription_id`) REFERENCES `subscription` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `subscription_organism` DISABLE KEYS;

INSERT INTO `subscription_organism` (`subscription_id`, `organism_id`) VALUES
(1,	1),
(1,	2),
(3,	1);
ALTER TABLE `subscription_organism` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `subscription_payment`;

CREATE TABLE `subscription_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subscription_id` int(11) NOT NULL,
  `check_number` int(11) NOT NULL,
  `amount` double NOT NULL,
  `deposit_date` datetime NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `check_order` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_1E3D64969A1887DC` (`subscription_id`),
  CONSTRAINT `FK_1E3D64969A1887DC` FOREIGN KEY (`subscription_id`) REFERENCES `subscription` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `subscription_payment` DISABLE KEYS;

INSERT INTO `subscription_payment` (`id`, `subscription_id`, `check_number`, `amount`, `deposit_date`, `status`, `check_order`) VALUES
(1,	1,	369523,	15,	'2020-08-29 00:37:13',	'non remis',	'escalamap'),
(2,	1,	55665613,	20,	'2020-08-29 00:37:13',	'non remis',	'region amap'),
(4,	3,	2147483647,	15,	'2020-08-30 10:03:01',	'non remis',	'escalamap');
ALTER TABLE `subscription_payment` ENABLE KEYS;



-- --------------------------------------------------------

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(180) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `adress` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `postcode` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `user` DISABLE KEYS;

INSERT INTO `user` (`id`, `email`, `roles`, `password`, `first_name`, `last_name`, `adress`, `city`, `postcode`, `phone1`, `phone2`, `member_type`, `created_at`) VALUES
(5,	'iparis@pages.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$c0Flc1BXaWlwSHl1NFdJbQ$OKt6VawS1rePULOUCQOaR2MJekN9PmZ5fCZchKpGku0',	'Olivier',	'Leblanc',	'99, impasse Marianne Caron\n60 570 Guillaume-sur-Tessier',	'Duval',	'15 072',	'+33 (0)8 13 75 03 10',	'02 21 42 02 27',	'Membre',	'2020-08-27 15:15:04'),
(6,	'gregoire73@wanadoo.fr',	'[\"ROLE_PRODUCER\"]',	'$argon2id$v=19$m=65536,t=4,p=1$WGZiOHFXQkY2NTVtZWV4aA$ZQGHRqAOlEKZGRSwlV4pyJDwyhEM8o37U4026bqL6xg',	'Jacques',	'Bourgeois',	'2, avenue Nathalie Ribeiro\n09564 Thibault-sur-Blin',	'Michaudnec',	'32206',	'03 46 34 99 90',	'03 33 21 64 31',	'Producteur',	'2020-08-27 15:15:04'),
(7,	'camille73@voila.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$amFDL2lPekoxMkI2bUgxYg$0tLrLKqCvO9f6eYDPjvGGvjQHtj+fopKEmaNnW5iNV0',	'Colette',	'Mallet',	'boulevard Royer\n40354 Torres',	'Hebertboeuf',	'05577',	'0690248120',	'0773357140',	'Membre',	'2020-08-27 15:15:04'),
(8,	'xbarbier@free.fr',	'[\"ROLE_REFERENT\"]',	'$argon2id$v=19$m=65536,t=4,p=1$d0ZXRVhwZi4zZUFyazVoTg$GgqMYgmcp95XnqOE9Hx1khUK3tk1a18RAzd9LcuT2J4',	'Maggie',	'Antoine',	'302, boulevard Guy Robin96 232 Barthelemy',	'Laporte',	'60081',	'0196319505',	'+33 8 29 84 23 51',	'Référent',	'2020-08-27 15:15:04'),
(9,	'monique.coulon@dbmail.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$NnN6dHFBaVAvNjJOVXRGSg$RxVrMBZFsr2J3w7Wj5A/7FSA0kKUjR88FM1NGCdDLtg',	'Éric',	'Laurent',	'991, rue de Gay\n36 340 Bertrand',	'Berthelotdan',	'26 256',	'01 52 35 73 26',	'0691581044',	'Membre',	'2020-08-27 15:15:05'),
(10,	'jledoux@clement.net',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$SEFraEcvY3NBdzkwN2FBdg$GktC1XjseCGFypHygQk0t9MrnFzvNheXrOzujSg0iAU',	'Noël',	'Gauthier',	'35, chemin de Guillot\n28 957 Albert',	'Roussetdan',	'46318',	'+33 2 52 84 25 06',	'05 80 53 13 63',	'Membre',	'2020-08-27 15:15:05'),
(11,	'alix92@tele2.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$WTZicC95TVJKOFFucUtzSg$6FXi0+kCyd+/gaKdvU5ASQR9k3KGQRy9iwbqOnZ0E5A',	'Denis',	'Marie',	'49, rue Thibaut Charpentier\n68754 Petitjean',	'Pierredan',	'71627',	'+33 (0)9 76 53 40 28',	'04 94 01 29 38',	'Membre',	'2020-08-27 15:15:05'),
(12,	'lejeune.alexandria@voila.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$UGVvUlUvWVJIY1FvMEVaRQ$94uRqZ/5R9fI4kPV8o248/js5YKHFvn6kj7+TWHxvwI',	'Audrey',	'Gallet',	'7, rue de Lopes\n45 344 Garnier',	'Jacques-sur-Barre',	'63604',	'+33 7 69 98 60 52',	'07 70 89 20 20',	'Membre',	'2020-08-27 15:15:06'),
(13,	'vmorin@lemaire.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$bDZQcGRDYXZBSEpVSEdSSg$1ad8Lp78vDUHUZ4DxJ2KeB/ONgxZ/3Rn8n00rLVakAE',	'Zoé',	'Morin',	'30, rue de Jacquot\n83 301 Lagarde-les-Bains',	'Lemonnier-sur-Maurice',	'69766',	'+33 8 98 29 99 32',	'06 09 16 83 77',	'Membre',	'2020-08-27 15:15:06'),
(14,	'masson.gilles@gmail.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$cmJvSllKNjBnZlVMaEZWNA$HpLGo4EeH+Pmn4X0nTTkmZnxtqLeYF40n9H9QEfwgIc',	'Sylvie',	'Jacques',	'498, impasse Véronique Camus\n64 633 Salmon-sur-Mer',	'Dupuy-sur-Leleu',	'72822',	'03 37 79 76 91',	'0231119580',	'Membre',	'2020-08-27 15:15:06'),
(15,	'eolivier@voila.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$NFNJdUthbTk4ejFuVTQ0bw$RjvUYAUWWC45dpey3DYZmqRJpF3tLOf6Zde3WsTKlxI',	'Margaux',	'Gomes',	'2, rue Thérèse Meunier\n78 683 Tanguy',	'Gilles-sur-Mer',	'82634',	'+33 (0)1 05 90 31 68',	'0803450425',	'Membre',	'2020-08-27 15:15:06'),
(16,	'david58@dumont.com',	'[\"ROLE_PRODUCER\"]',	'$argon2id$v=19$m=65536,t=4,p=1$ZXNPbXlDU1p4UlFCeWZ1Zg$Tsm9xVr++ggrUf7cRrnki89m3rhgYs7TpqoVhE/ZnmY',	'Léon',	'Besson',	'17, impasse de Munoz\n42 089 Hernandez-les-Bains',	'Lemonniernec',	'13 681',	'0795369462',	'07 58 57 49 78',	'Producteur',	'2020-08-27 15:15:07'),
(18,	'mmartin@gilbert.net',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$UmJ6cFlBYnM5R2d6TVh0WA$R9ZPom3ev5PGjzwHcr+MxeSOALu2l/tDN7D/Qhysq08',	'Olivie',	'Fleury',	'rue Diallo\n51 003 Normand-les-Bains',	'CordierBourg',	'48 001',	'+33 4 49 69 88 49',	'09 81 73 09 69',	'Membre',	'2020-08-27 15:15:07'),
(19,	'qmerle@sfr.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$SnBDdktVWUtvWC5RT3UuNw$JOwWIgojQfWsMxHAazVMpQSZPhpLkuv1oUe95Qf2nbw',	'Isaac',	'Pelletier',	'73, impasse de Texier\n87 159 Jourdan',	'Bourdon',	'19 957',	'+33 (0)5 25 91 52 73',	'+33 (0)6 18 86 16 91',	'Membre',	'2020-08-27 15:15:07'),
(20,	'nhuet@texier.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$SkF0ODZqNTI0RE4xdW0ySA$IBQlALtnJw5iibfLdwFOBUTqXvzdX81/ApZsYyCyPmw',	'Astrid',	'Rousseau',	'12, place Antoine Marion\n50 680 Besson-les-Bains',	'Pierre-sur-Da Costa',	'62499',	'07 35 09 61 49',	'+33 5 25 96 31 67',	'Membre',	'2020-08-27 15:15:08'),
(21,	'roger93@bourgeois.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$S0ZWaUZmZEMxT2JzMndJRQ$qNvPFL85JRasc16DzqttMjy6rHBd7iCKO66EE6S+kgg',	'François',	'Roy',	'16, impasse de Pruvost\n80 414 Royer-sur-Morel',	'Guilbert',	'65825',	'02 57 22 33 53',	'+33 (0)8 13 75 05 22',	'Membre',	'2020-08-27 15:15:08'),
(22,	'honore39@gillet.net',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$aGphbXdZOXNKRzc3Z1FHcg$yRjeNGU7pFbu/XsYphYwuk8vmAvEkA9OSfqWQVecI1U',	'Philippine',	'Renard',	'969, chemin Mary\n47863 Mauricenec',	'PottierBourg',	'86 836',	'+33 6 83 45 41 08',	'0571742153',	'Membre',	'2020-08-27 15:15:08'),
(23,	'hugues49@lacroix.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$dlgvb2J6RzVrc1A4dVlhNg$+g/aLcVyfjjUI6DmZ51h/WdycM4AqN+IfkZuwpmvj6M',	'Pierre',	'Delaunay',	'11, boulevard Léon Traore\n32 300 Pons-sur-Renaud',	'Gautier',	'20708',	'09 89 36 86 80',	'05 00 24 25 53',	'Membre',	'2020-08-27 15:15:09'),
(24,	'maillot.gabriel@club-internet.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$WnRyeWkuLlR4QzVjc1BreA$UEr1KvrEdqDEbcIONY7SSBTgr321a/KjjSnxn4FTMsI',	'Richard',	'Perez',	'2, rue de Brun\n16 102 PoulainVille',	'LucasVille',	'33677',	'+33 6 70 68 04 06',	'0811905911',	'Membre',	'2020-08-27 15:15:09'),
(25,	'clegros@club-internet.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$Yk1KbXZLVzgvUDYvNDVEWQ$9SVCo7kpXgCi3ISsKjWkgoe1iW4iUx+AVKAGVbuhL2w',	'Simone',	'Parent',	'903, place Georges Perrin\n35 969 Boutin-sur-Leclerc',	'Raynaud-sur-Bonnet',	'25 080',	'+33 8 13 34 32 85',	'0802650822',	'Membre',	'2020-08-27 15:15:09'),
(26,	'gabriel.pineau@chauvin.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$aTlYWEZrNUcvMk9TL2E2WQ$WtQIk4Hj8FN8BqjXjKvFfqn9ZUNaGSHVbRw6dE3HF9Y',	'Simone',	'Lecomte',	'7, place Emmanuel Sauvage\n98390 Poulain',	'Bonneau',	'61168',	'+33 (0)2 56 07 79 53',	'0623997635',	'Membre',	'2020-08-27 15:15:09'),
(27,	'vtoussaint@live.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$SmZQbVVEUWxETmR2NzlBbg$c0r/8OOW65hmLyECE8+1VViTol6ccx6aRpoxA5dkrE0',	'Victor',	'Michel',	'22, avenue de Besson\n22 839 Lefevre',	'Martel',	'65930',	'+33 6 49 93 58 16',	'09 97 93 10 23',	'Membre',	'2020-08-27 15:15:10'),
(28,	'roy.emmanuel@gillet.org',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$MnRsbU9xUlZjUkw2YmVCTw$AyRj9hK76iwkDFx222OwC0JIojWZOOKkQqCyifUXEOU',	'François',	'Thierry',	'14, chemin Claude Hernandez\n86943 MaillardBourg',	'Gerard',	'21716',	'01 34 94 05 18',	'0498202681',	'Membre',	'2020-08-27 15:15:10'),
(29,	'mchevalier@barre.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$NW9zbjdVL0ExVGNKZTJBVw$1Q61yyxBv3XvB+SFnfX2Gcpj/A0eT5P8V3UetWRphAg',	'Denis',	'Riou',	'42, avenue de Riou\n18479 Fernandes-la-Forêt',	'Garcia',	'30071',	'+33 7 90 65 22 31',	'+33 6 42 14 10 51',	'Membre',	'2020-08-27 15:15:10'),
(30,	'marc86@lelievre.fr',	'[\"ROLE_PRODUCER\"]',	'$argon2id$v=19$m=65536,t=4,p=1$TGdDV0hBa1V6YXRMLzR2eQ$DuDWdBqcP3xPARaIkY2E5XjL0Ck4hzgpcH/OZofJwHg',	'Charles',	'Da Silva',	'99, rue de Briand\n06042 Jacques-sur-Perrin',	'Letellier',	'54 316',	'07 72 83 33 44',	'+33 8 97 47 33 69',	'Producteur',	'2020-08-27 15:15:10'),
(31,	'arthur05@peltier.org',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$aFgvMC9LdGJNdy5ITWs2cQ$Ya8hb+eij3ljfyHbrGvp16NqNGmys+OnuWRLfih0U9w',	'Gabrielle',	'Fouquet',	'8, chemin Hugues Leduc\n85 475 Bodin',	'Grondin-sur-Leclercq',	'61556',	'+33 9 77 99 46 80',	'0569748285',	'Membre',	'2020-08-27 15:15:11'),
(32,	'lmace@dbmail.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$RjRya1RMNURCSHdqUWpjLg$1evbAeI1gjnW5fvXXfWrtJHcH9BHWNUlkH33qOKI51o',	'Susanne',	'Techer',	'chemin Zoé Boyer\n06 642 Breton-sur-Techer',	'Bonneau',	'30384',	'0484585355',	'+33 7 89 46 63 41',	'Membre',	'2020-08-27 15:15:11'),
(33,	'ylucas@clement.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$STEwVC42cG5vZkNEdW5GTw$Hw9KvPCKL4Zl+O5ZFXPBdewBHk1f+UvQ5Ji/FULkNeY',	'William',	'Ramos',	'88, impasse Gilbert\n60260 Ponsboeuf',	'Jacquetdan',	'42285',	'0798527836',	'+33 9 15 92 64 48',	'Membre',	'2020-08-27 15:15:11'),
(34,	'faure.audrey@bouygtel.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$WkQvNVhLNnBCSE9TQ3ozMQ$bjXI9RaeusylrGf7hrKm/RJ0gakGMwITutc3R1Q3C5w',	'Isaac',	'De Oliveira',	'30, chemin de Ribeiro\n34 363 Robert-sur-Gregoire',	'Dupont-sur-Begue',	'19171',	'0973159637',	'+33 7 53 90 45 87',	'Membre',	'2020-08-27 15:15:12'),
(35,	'laetitia52@legrand.net',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$Y29wbmJTYUNWVzlZRHg4dQ$m+b4C+BYQ4BS/8YCgtiR56eZtsnHf7EJr2at2exNP3g',	'Léon',	'Simon',	'29, boulevard de Pereira\n75473 Hubertboeuf',	'Laurentnec',	'18 840',	'+33 (0)1 07 46 65 93',	'0190330839',	'Membre',	'2020-08-27 15:15:12'),
(36,	'susan.lebrun@ifrance.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$anJaS1YySkxiSzJPRVlndA$nFB0PYQYZFPn/bC4ljuMWqJgId/IwTEcjw5TAFa9EF8',	'Henriette',	'Collin',	'54, rue de Cohen\n62 704 Begue-les-Bains',	'BodinBourg',	'78 582',	'+33 (0)1 59 45 88 95',	'0664654090',	'Producteur',	'2020-08-27 15:15:12'),
(37,	'christelle.roy@colin.net',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$Y3NKU2xRc3pXd3ZZNVE3cQ$MFK58/ydTWpQ+urVLlP19n1GIeYm/pruUjJ828GbF6o',	'Anouk',	'Gautier',	'72, impasse Émile Dias\n17 701 Descamps-les-Bains',	'Pages',	'25838',	'+33 4 13 05 12 00',	'0554341637',	'Membre',	'2020-08-27 15:15:12'),
(38,	'jules53@dbmail.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$ZTJFcVJ5QUJRUFpCMEc3TQ$MZes3jn8E+Gg6+mOve6E/2slfl7Z5K6wbcCYQ5Lh7s0',	'Clémence',	'Mary',	'48, place Joséphine Barre\n34 416 Leveque-la-Forêt',	'Diallo-sur-Petitjean',	'70 686',	'07 93 73 50 38',	'+33 (0)1 83 00 13 45',	'Membre',	'2020-08-27 15:15:13'),
(39,	'huet.lucie@deoliveira.net',	'[\"ROLE_TREASURER\"]',	'$argon2id$v=19$m=65536,t=4,p=1$bnJGUGdBTFFsLjlrdVhnMw$NEtz1zhLAKn1t4+WdzaxTMkeoMijn9wJCsXCuQkfZds',	'Camille',	'Barbe',	'51, rue Adrienne Dupuis48239 Labbe-sur-Mer',	'Moreldan',	'18081',	'0489770470',	'+33 (0)3 05 89 11 74',	'Trésorier',	'2020-08-27 15:15:13'),
(40,	'imahe@leveque.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$ZE5sQ1dWZy50eXNWOC9NTw$bYLSLFMTpxouUAS1BBQXmyNeaVThIHZHuRy99ojsL0c',	'Auguste',	'Gomez',	'40, impasse Leblanc\n80 308 Nguyen',	'RodriguesBourg',	'48 476',	'04 51 87 40 11',	'05 39 44 57 87',	'Membre',	'2020-08-27 15:15:13'),
(41,	'ruiz.louis@samson.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$TzZqQTNzWWd3aW1NeUp5RA$2+Pi5sQbBmBPJvOs+dTo29ZJhXLU+qt959tbQ/vKbSE',	'Olivier',	'Carre',	'10, chemin Charpentier\n51 123 Labbe',	'Humbert',	'07338',	'+33 (0)1 80 33 86 67',	'+33 1 66 00 72 14',	'Membre',	'2020-08-27 15:15:13'),
(42,	'qbrunet@dbmail.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$RWt2YjE1NmEvRlFpWlg0Mg$ydNvwpma7Tg243xq+/SEQrKrUKh0HDUpdiF1Mirl2ac',	'Nath',	'Rocher',	'4, rue Laurence Girard\n17 058 BlanchetBourg',	'Chauvet',	'40 370',	'+33 1 90 49 01 56',	'+33 8 06 81 24 01',	'Membre',	'2020-08-27 15:15:14'),
(43,	'sdossantos@laposte.net',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$dnY0MFVDY29lMGRDVFZOWA$v8hV+P4hQJVqBpophrR2Vsj+pEpYQnOJOMa+l7a4mt0',	'Aimée',	'Delorme',	'37, place Hoarau\n57 268 Renault',	'Thierrydan',	'21247',	'+33 8 08 61 07 11',	'0672454991',	'Membre',	'2020-08-27 15:15:14'),
(44,	'noemi.auger@fernandez.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$aTVSakJ4ZFU4ektUNnRxYQ$mFKuBI2wBPHYMj8GBAeN4YhWbx4buDUDLVjpmEXksTU',	'Mathilde',	'Rodrigues',	'33, boulevard Arnaude Rousseau\n55 011 Bousquet',	'Gomes',	'19 230',	'0290603341',	'04 48 66 70 17',	'Membre',	'2020-08-27 15:15:14'),
(45,	'mdidier@gmail.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$MkxQdktpMlE3bFhWc2djNQ$3tIPD2rdBwpap0w9qXwOPnycqFKT+PeHdWm0QCIbBKA',	'Stéphanie',	'Pons',	'89, boulevard Benjamin Hardy\n64 064 Albert',	'Dupont',	'38 110',	'0211636335',	'+33 1 82 91 45 90',	'Membre',	'2020-08-27 15:15:15'),
(47,	'marcel.delahaye@regnier.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$TWlkS0t2UlRUZjVhdDJYeA$hyos+xXgEjMhaaBVZ9u05EfS+eWyaDIWnv2XwVLa2Nc',	'Tristan',	'Mendes',	'impasse de Chevallier\n60 799 Fournier',	'Thibault',	'25657',	'0209719696',	'01 92 73 09 81',	'Membre',	'2020-08-27 15:15:15'),
(48,	'marc.payet@ifrance.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$ZTlKUzJmazVMZTVYZnVLVQ$p/9YkdJaOAgEenV+Z8tLwwxhyPPeBrNfOwF7f/+JKlg',	'Christelle',	'Delannoy',	'9, impasse Leroux\n52280 Bouvier-sur-Mer',	'Germain',	'41462',	'+33 (0)3 59 24 40 60',	'+33 (0)9 52 40 93 34',	'Membre',	'2020-08-27 15:15:15'),
(49,	'dlabbe@tele2.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$Y1c5WHphbmdzaC9NYmFJdQ$zgu0kFLrGe5h0jNqv06TaSPgv72C2y5E7UGLxw4Zw2U',	'Gilles',	'Pasquier',	'1, place Fouquet\n50414 Gaudin',	'Leveque',	'32564',	'+33 (0)2 22 18 45 87',	'+33 (0)1 78 03 36 05',	'Membre',	'2020-08-27 15:15:16'),
(50,	'marc31@buisson.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$VUZURXJpcXFZcENCcWJ4cQ$Dkkc6bxdgFKDNNcj1VeB0nWeuBMGiCYy6ZBCvghXoLI',	'Vincent',	'Lombard',	'97, avenue Henriette Grenier\n60 317 Pages-sur-Bourdon',	'Evrarddan',	'49 043',	'+33 (0)3 97 28 62 67',	'+33 2 76 15 15 33',	'Membre',	'2020-08-27 15:15:16'),
(51,	'laurent.thomas@seguin.com',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$VFV5dXFaTzhRMzdSaTFtTA$HQW5fI+5uz4ZVvL4DSicBoAWYtClOPeavve89IryA34',	'Andrée',	'Neveu',	'217, place Andre\n56630 Camus-les-Bains',	'Herve-les-Bains',	'61301',	'+33 (0)8 92 60 06 26',	'+33 1 64 25 49 60',	'Membre',	'2020-08-27 15:15:16'),
(52,	'penelope.desousa@blanchet.fr',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$VjA1Ym52cDRWSVVJNVBtTg$IKNHIIKnqAyeGrPBv/TWejfzQ4PyKstfFzwxrRtide0',	'Alphonse',	'Mercier',	'40, rue de Cousin\n15 158 Ledoux-sur-Michel',	'Lopez',	'42 884',	'+33 (0)6 75 02 47 49',	'+33 (0)8 91 89 69 36',	'Membre',	'2020-08-27 15:15:17'),
(53,	'louise.perret@voila.fr',	'[\"ROLE_REFERENT\"]',	'$argon2id$v=19$m=65536,t=4,p=1$VmlHemttNlRVWDYuZlVPQw$dAlVAbLUVjJFqPUsOgHCBX7GBx65bh/eHSHxYm7W5CI',	'Pierre',	'Barbier',	'avenue Claude Hernandez31 306 ChauvetVille',	'Weiss',	'98272',	'+33 (0)6 40 88 46 37',	'0978190634',	'Référent',	'2020-08-27 15:15:17'),
(54,	'xbreton@vaillant.org',	'[]',	'$argon2id$v=19$m=65536,t=4,p=1$aXJuMk1ySm5PUThMQU5VQg$zqumKaWSgqX+KsRVG8FNyOTIaS3g38CGs7TlQbKLw9k',	'Margaud',	'Moulin',	'impasse Catherine Lagarde\n36 912 Gerard-les-Bains',	'Potier-sur-Gregoire',	'86 579',	'+33 6 04 21 60 96',	'03 59 43 41 96',	'Membre',	'2020-08-27 15:15:17'),
(55,	'gregory.thorel@live.fr',	'[\"ROLE_ADMIN\"]',	'$argon2id$v=19$m=65536,t=4,p=1$aTY1UHo5UVpYM3NrZkVOZw$ZIQDNOBKCvFT0B5iXg2NYmfHeaNFz4pj+tTolWJquws',	'greg',	'thorel',	'1 chemin de la bergerie',	'toulouse',	'31000',	'0781947230',	NULL,	'Administrateur',	'2020-08-27 15:18:28');
ALTER TABLE `user` ENABLE KEYS;



COMMIT;
-- THE END
